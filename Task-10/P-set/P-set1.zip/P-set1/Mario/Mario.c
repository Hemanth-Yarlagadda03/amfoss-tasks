#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int h;
    do
    {
        h= get_int("Height: ");
    }
    while (h < 1 || h > 8);

    for (int r= 0; r< h; r+=1)
    {
        for (int space = h - r - 1; space > 0; space-=1)
        {
            printf(" ");
        }
        for (int hash = 0; hash < r + 1; hash++)
        {
            printf("#");
        }
        printf("\n");
    }
}